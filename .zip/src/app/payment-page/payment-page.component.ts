import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-page',
  templateUrl: './payment-page.component.html',
  styleUrls: ['./payment-page.component.scss']
})
export class PaymentPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    setTimeout(()=>{
      document.getElementById('connect')?.click();
    },2000)

  }

}
